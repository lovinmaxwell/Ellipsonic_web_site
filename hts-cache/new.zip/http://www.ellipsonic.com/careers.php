<!DOCTYPE html>
<html>
  <head>
  <meta name="google-site-verification" content="_kXVPYNk1GMLFnNuiIJO_AI04fnfBCaMp3FZ2sk0vVQ" />
    <meta charset="utf-8">
    <!-- PAGE TITLE -->
    <title>Our Skills - Ellipsonic</title>
    <!-- MAKE IT RESPONSIVE -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#D9534F">
    <!-- SEO -->
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <!-- FAVICON -->	
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"><link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- STYLESHEETS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/font-awesome.min.css" rel="stylesheet" media="screen">
    <link href="css/style.css" rel="stylesheet" media="screen">
         <link rel="icon" type="image/png" href="images/logo-droid.png" sizes="184x184" title=“logo”>
    <!-- FONTS -->
    <link href='http://fonts.googleapis.com/css?family=Droid+Serif:400,400italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:900,300,400,200,800' rel='stylesheet' type='text/css'>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
	<script src="js/jquery-1.11.1.min.js"></script>
	
  </head>
  <!-- START BODY -->
  <body>

  	<div id="page">
	  	<!-- START HEADER -->
	  	<header id="header" class="small with-separation-bottom">
	  		<!-- POINTER ANIMATED -->
	  		<canvas id="header-canvas"></canvas>
	  		
	  		<!-- TOP NAVIGATION -->
	  		<div id="top-navigation">
		  		<ul class="animate-me fadeInDown" data-wow-duration="1.2s">
			  		<li class="menu-item"><i class="fa fa-phone"></i>+91 988 679 6816</li>
					<li class="menu-item"><i class="fa fa-phone"></i>+65 96 46 0583</li>
			  		<!-- <li class="menu-item"><a href="faq.html"><i class="fa fa-question"></i> FAQ</a></li> -->
			  		<!-- <li class="menu-item"><a href="page.html"><i class="fa fa-link"></i> Just a link</a></li> -->
			  		<li class="menu-item"><span class="navigation-social">We're social !</span> <a href="https://www.facebook.com/ellipsonic/" target="_blank"><i class="fa fa-facebook"></i></a> <a href="https://twitter.com/ellipsonic" target="_blank"><i class="fa fa-twitter"></i></a> <a href="https://www.youtube.com/channel/UCJU-RZoxmdwWjq3c-3zD_Bw" target="_blank"><i class="fa fa-youtube"></i></a> <a href="https://plus.google.com/u/0/b/109189476800068313638/109189476800068313638/about/p/pub" target="_blank"><i class="fa fa-google"></i></a></li>
			  		<!--<li class="menu-item">
			  			<div id="search-container" class="animate-me fadeInDown">
					  		<form role="search" method="get" action="#" >
								<input type="text" value="" name="s" id="s" placeholder="Search..."/>
								<input type="hidden" name="searchsubmit" id="searchsubmit" value="true" />
								<button type="submit" name="searchsubmit"><i class="fa fa-search"></i></button>
					        </form>
				  		</div>
			  			<a href="#" id="search-toggle"><i class="fa"></i></a>
			  		</li>-->
			  		<li class="menu-item menu-item-has-children language-switcher">
			  			
			  			<a href="#"><i class="fa fa-flag"></i> English <i class="fa fa-angle-down"></i></a>
				  		<!-- LANGUAGES
				  		<ul class="sub-menu bounceInDown">
				  			<li class="menu-item"><a href="#">French</a></li>
				  			<li class="menu-item"><a href="#">Chinese</a></li>
				  			<li class="menu-item"><a href="#">German</a></li>
			  			</ul> -->
			  		</li>
		  		</ul>
	  		</div>
	  	
	  		<!-- MOBILE NAVIGATION -->
	  		<nav id="navigation-mobile"></nav>
	  	
	  		<!-- MAIN MENU -->
	  		<nav id="navigation">
	  			<!-- DISPLAY MOBILE MENU -->
	  			<a href="#" id="show-mobile-menu"><i class="fa fa-bars"></i></a>
	  			<!-- CLOSE MOBILE MENU -->
		  		<a href="#" id="close-navigation-mobile"><i class="fa fa-long-arrow-left"></i></a>
	  			
		  		<ul id="left-navigation" class="animate-me fadeInLeftBig">
			  		<li class="menu-item menu-item-has-children">
			  			<!-- <a href="index.html" data-description="All starts here">Home</a> -->
			  			<!-- <ul class="sub-menu bounceInDown">
			  				<li class="menu-item"><a href="index.html">Slider fullscreen</a></li>
				  			<li class="menu-item"><a href="index2.html">Video fullscreen</a></li>
				  			<li class="menu-item"><a href="index3.html">Single Image</a></li>
				  			<li class="menu-item"><a href="index-onepage.html"><i class="fa fa-star"></i> One Page</a></li>
			  			</ul> -->
			  		</li>
			  		<!-- <li class="menu-item menu-item-has-children">
			  			<a href="portfolio.html" data-description="What we do">Portfolio</a>
			  			<ul class="sub-menu bounceInDown">
			  				<li class="menu-item"><a href="portfolio.html">All Projects</a></li>
				  			<li class="menu-item"><a href="portfolio-single.html">Single Project</a></li>
				  			<li class="menu-item"><a href="faq.html">FAQ</a></li>
			  			</ul>
			  		</li> -->
			  		<li class="menu-item"style="padding-bottom: 0px;"><a href="skills.html">Skills<br><span class="tag-title-description">We're the best<span></a></li>
					<li class="menu-item"style="padding-bottom: 0px;"><a href="about.html">About<br><span class="tag-title-description">We are a team<span></a></li>
		  		</ul>
		  		<div  class="animate-me flipInX" data-wow-duration="3s">
		  			<a href="http://ellipsonic.com" id="logo-navigation">
		  				
		  			</a>
		  		</div>
		  		<ul id="right-navigation" class="animate-me fadeInRightBig">
			  		<li class="menu-item current-menu-item"style="padding-bottom: 0px;"><a href="careers.php">Careers<br><span class="tag-title-description">We are hiring<span></a></li>
			  		<!--<li class="menu-item menu-item-has-children">
			  			<a href="blog.html" data-description="We share">Blog</a>
			  			<ul class="sub-menu bounceInDown">
				  			<li class="menu-item"><a href="blog.html">All Posts</a></li>
				  			<li class="menu-item"><a href="blog-single.html">Single Post</a></li>
			  			</ul>
			  		</li>-->
			  		<li class="menu-item"style="padding-bottom: 0px;"><a href="contact.html" >Contact<br><span class="tag-title-description">Let's get in touch<span></a></li>
		  		</ul>
	  		</nav>

	  		<!-- SHADOW -->
	  		<div id="shade"></div>

	  		<!-- HEADER SLIDER -->
		  	<div class="flexslider" id="header-slider">
		  		<ul class="slides">
		  			<li><img src="images/backgrounds/blue.jpg" alt="" title=“blue background”></li>
		  		</ul>	
		  	</div>
	  		
	  	</header>
	  	<!-- END HEADER -->
	  	
	  	<!-- START MAIN CONTAINER -->
	  	<div class="main-container">
	  		<div class="container">
	  			<!-- SKILLS -->
	  			<h2 class="with-breaker animate-me fadeInUp">
		  			Careers
	  			</h2>
	  			<p class="center">We are hiring, if you think you are the right one, please click on Apply now button and upload your resume</p>
				<p class="center"> OR </P>
	  			     <p class="center">Send your resume to careers@ellipsonic.com</p>
					 
					 <div class="alert alert-info">
                                       <strong>Currently we are hiring experts from diverse technical and nontechnical fields for below positions.</strong><br><br> Mobility developers, Marketing executives, Software architects, Project managers, CEO, Trainers.<br><br> Part-timers and Freelancers are also welcome to apply.
                                      </div>
	  			<div class="tabs-container">
	  				<ul class="nav nav-tabs" role="tablist" id="SkillsTab">
						<li class="active"><a href="#skill1" role="tab" data-toggle="tab"><i class="fa fa-mobile"></i> Mobility Developers</a></li>
						<li><a href="#skill2" role="tab" data-toggle="tab"><i class="fa fa-code"></i> Programmers</a></li>
						<li><a href="#skill4" role="tab" data-toggle="tab"><i class="fa fa-briefcase"></i> Marketing & Sales Executives</a></li>
						<li><a href="#skill5" role="tab" data-toggle="tab"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> Software architects</a></li>
						<li><a href="#skill6" role="tab" data-toggle="tab"><i class="fa fa-eye"></i> Project Managers</a></li>
						<li><a href="#skill7" role="tab" data-toggle="tab"><i class="fa fa-university"></i> Trainers</a></li>
						
						<li><a href="#skill3" role="tab" data-toggle="tab"><i class="fa fa fa-paper-plane"></i> Interns</a></li>
					</ul>

					<div class="tab-content">
						<div class="tab-pane active bounceInRight" id="skill1">
							<h2><i class="fa fa-mobile"></i>Mobility Developers</h2>
							<h4 style="text-transform:none;font-weight:normal;"><i class="fa fa-map-marker"></i> India</h4>
							<p class="text-justify">We are looking for a talented Mobility Developers. You’ll collaborate with our team members to implement innovative solutions for our products, play a key role in  developing mobile applications.</p>
							<div class="row">
								<div class="col-md-6">
				  					<ul>
				  						<li>A solid portfolio of mobile and/or other UI design work</li>
				  						<li>Understand requirement and come up with a design for developing mobile applications.</li>
				  						<li>Familiarity with designing on top of AngularJS, Ionic and Hybrid.</li>
				  						<li>Develop web services to interact with back-end data stores.</li>
									</ul>
			  					</div>
			  					<div class="col-md-6">
				  					<ul>
									    <li>Design and build advanced applications for the Android/iOS platform</li>
										<li>Work on bug fixing and improving application performance.</li>
				  						<li>Obsessive attention to detail</li>
				  						<li>Broader visual design experience is a bonus</li>
				  						<li>Able to work in a team and independently when needed</li>
				  						<li>Able to clearly articulate the rationale for your designs</li>
				  					</ul>
			  					</div>
							</div>

						</div>
						<div class="tab-pane bounceInRight" id="skill2">
							<h2><i class="fa fa-code"></i>Programmers</h2>
							<h4 style="text-transform:none;font-weight:normal;"><i class="fa fa-map-marker"></i> India</h4>
				  			<p class="text-justify">We are looking for programmers, web developers, Android & iOS app developers on full-time / contract basis, To join our team we have the following process</p>
							<div class="row">
								<div class="col-md-6">
				  					<ul>
				  						<li>Diversified skill set to work on larger projects with minimal supervision</li>
				  						<li>Able to work on a team and independently when needed</li>
				  						<li>Able to manage time across several projects</li>
				  						<li>Eager to collaborate, learn and figure things out</li>
				  						<li>Experience with basics of SQL back-end database architecture</li>
				  					</ul>
			  					</div>
			  					<div class="col-md-6">
				  					<ul>
				  						<li>Proficient in writing SQL and stored procedures</li>
				  						<li>Well-versed and experienced in object-oriented programming, Objective C specifically</li>
				  						<li>Experience with JavaScript, AJAX, and jquery</li>
				  						<li>Experience with developing Asp.Net, php, AngularJS MVC web applications</li>
				  						<li>Experience testing own code prior to roll-out</li>
				  					</ul>
			  					</div>
							</div>
						</div>
						<div class="tab-pane bounceInRight" id="skill4">
							<h2><i class="fa fa-briefcase"></i>Marketing & Sales executives</h2>
							<h4 style="text-transform:none;font-weight:normal;"><i class="fa fa-map-marker"></i> India</h4>
				  			<p class="text-justify">We are looking for a results driven Marketing & Sales executives to be responsible for all marketing & sales activities, from lead generation through to close. The successful candidate will be able to elevate company standards, achieve sales goals and meet clients expectations & also to contribute to and develop integrated marketing campaigns.
							</p>
							<div class="row">
								<div class="col-md-6">
				  					<ul>
				  						<li>Liaising and networking with a range of stakeholders including customers, colleagues, suppliers and partner organisations</li>
				  						<li>Communicating with target audiences and managing customer relationships</li>
				  						<li>Sourcing advertising opportunities and placing adverts in the press or on the radio</li>
				  						<li>Managing the production of marketing materials, including leaflets, posters, flyers, newsletters, e-newsletters and DVDs</li>
				  						<li>Actively seek out customers in store</li>
				  					</ul>
			  					</div>
			  					<div class="col-md-6">
				  					<ul>
				  						<li>Contributing to and developing, marketing plans and strategies</li>
				  						<li>Supporting the marketing manager and other colleagues.</li>
				  						<li>Organising and attending events such as conferences, seminars, receptions and exhibitions</li>
										<li>Design, build and maintain our social media presence</li>
										<li>Manage SEO/SEM, marketing database, email, social media and display advertising campaigns</li>
										<li>“Go the extra mile” to drive sales</li>
				  						<li>Evaluating marketing campaigns</li>
				  					</ul>
			  					</div>
							</div>
						</div>
						<div class="tab-pane bounceInRight" id="skill5">
							<h2><i class="fa fa-paper-plane-o"></i>Software Architects</h2>
							<h4 style="text-transform:none;font-weight:normal;"><i class="fa fa-map-marker"></i> India</h4>
				  			<p class="text-justify">We are looking for an experienced Software Architect to make intuitive high level decisions for software development. You will see the “big picture” and create architectural approaches for software design and implementation to guide the development team.<br> 
							The goal is to provide a framework for the development of a software or system that will result in high quality IT solutions.</p>
							<div class="row">
								<div class="col-md-6">
				  					<ul>
				  						<li>Participate in and lead design and code reviews</li>
				  						<li>Mentor team members in adopting technologies and tools that you are already familiar with, but which may be new to them</li>
				  						<li>Work on infrastructure backlog tasks as assigned</li>
				  						<li>Participate in scrum agile development process</li>
				  						<li>Perform evaluation and testing of the capabilities, characteristics and requirements of existing and emerging information systems technologies and make recommendations as to feasibility of implementation</li>
				  					</ul>
			  					</div>
			  					<div class="col-md-6">
				  					<ul>
				  						<li>Design, develop and implement unit and scenario based tests</li>
				  						<li>Communication: Excellent verbal and written communication.</li>
				  						<li>Assertive: Ability to assert his/her view point in all relevant forums.</li>
				  						<li>Leadership: Ability to lead development projects with medium size teams and get the desired results.</li>
				  						<li>Passion for technology: Active involvement on various technology communities.</li> <li>Past track record of participation in seminars/forums, keeping updated on evolving technologies, awareness of thought leaders of the industry is a plus point.</li>
				  					</ul>
			  					</div>
							</div>
						</div>
						<div class="tab-pane bounceInRight" id="skill6">
							<h2><i class="fa fa-eye"></i>Project Manager</h2>
							<h4 style="text-transform:none;font-weight:normal;"><i class="fa fa-map-marker"></i> India</h4>
				  			<p class="text-justify">We are looking for a Project Manager who will take on the management of key client projects. Project management responsibilities include delivering every project on time, within budget and within scope. </p>
							<div class="row">
								<div class="col-md-6">
				  					<ul>
				  						<li>Coordinate internal resources and third parties/vendors for the flawless execution of projects.</li>
				  						<li>Ensure that all projects are delivered on-time, within scope and within budget.</li>
				  						<li>Assist in the definition of project scope and objectives, involving all relevant stakeholders and ensuring technical feasibility.</li>
				  						<li>Ensure resource availability and allocation.</li>
				  						<li>Develop a detailed project plan to monitor and track progress.</li>
				  					</ul>
			  					</div>
			  					<div class="col-md-6">
				  					<ul>
				  						<li>Excellent client-facing and internal communication skills.</li>
				  						<li>Excellent written and verbal communication skills.</li>
				  						<li>Solid organizational skills including attention to detail and multi-tasking skills.</li>
				  						<li>Strong working knowledge of Microsoft Office, Open Office.</li>
				  						
				  					</ul>
			  					</div>
							</div>
						</div>
						<div class="tab-pane bounceInRight" id="skill7">
							<h2><i class="fa fa-university"></i>Trainer</h2>
							<h4 style="text-transform:none;font-weight:normal;"><i class="fa fa-map-marker"></i> India</h4>
				  			<p class="text-justify">We are looking for excellent trainers who can teach confidently and smartly. If you have great experience in training in any of the following. </p>
							<div class="row">
								<div class="col-md-6">
				  					<ul>
									    <li>Android, iOS</li>
									    <li>Web Development and related technologies like AngularJS</li>
										<li>Java and related technologies</li>
				  						<li>C,C++, Data Structure, Unix</li>
				  						<li>Digital Marketing</li>
				  						
				  					</ul>
			  					</div>
			  					<div class="col-md-6">
				  					<ul>
				  						<li>Big Data and related technologies</li>
				  						<li>Databases</li>
				  						<li>Oracle Server</li>
				  						<li>SQl Server</li>
				  						
				  					</ul>
			  					</div>
							</div>
						</div>
						<div class="tab-pane bounceInRight" id="skill3">
							<h2><i class="fa fa fa-paper-plane"></i>Interns</h2>
							<h4 style="text-transform:none;font-weight:normal;"><i class="fa fa-map-marker"></i> India / Singapore</h4>
				  			<p class="text-justify">We are looking for intelligent and responsible interns who have an interest in gaining valuable professional experience working in a start-up environment. Our interns work on a variety of projects depending on their interests and skill areas. Our needs range from building custom computers, performing research on a specific area and / or documenting our development processes to creating new products which in-turn helps in solving real-world problems.</p>
							<p class="text-justify">We give our interns real-time projects and products to work on. Interns are expected to work between 10 and 40 hours a week, depending upon their availability.</p>
							<div class="row">
								<div class="col-md-6">
				  					<ul>
				  						<li>Strong analytical and problem solving skills</li>
				  						<li>Ability to commit to a schedule</li>
				  						<li>Attention to detail</li>
				  						<li>Excellent interpersonal and communication skills</li>
				  						<li>Rapid and motivated self-learner</li>
				  					</ul>
			  					</div>
							</div>
						</div>
							<div class="row">
								<div class="col-md-12">
									<center><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Apply now</button><p>OR <br>Send your resume to careers@ellipsonic.com</p></center>
							</div>
					</div>
					
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog" style="margin-top: 100px;z-index:1050;">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel" style="margin-top: 0px;">We are hiring</h4>
						  </div>
						  <div class="modal-body">
							<form method="POST" id="careerForm" data-toggle="validator" action="careers_processing.php" enctype="multipart/form-data">
							  <div class="form-group">
								<label for="exampleInputEmail1">Email address *</label>
								<input type="email" class="form-control" id="exampleInputEmail1" name="email"
								 placeholder="Enter email" required>
							  </div>
							  <div class="form-group">
								<label for="exampleInputPassword1">Social Profile *</label>
								<input type="text" class="form-control" id="socialInput" name="linkedinProfile" placeholder="Linked in / Gplus / Facebook profile page link" required>
							  </div>
							  <div class="form-group">
								<label for="exampleInputFile">Your resume *</label>
								<input type="file" id="resumeInputFile" name="resumeInputFile" accept="application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint, text/plain, application/pdf, image/*" required>
								<p class="help-block">Upload your resume (doc, docx, pdf, ppt, img files only)</p>
							  </div>	
								<input type="hidden" value="UI / UX designers" name="skill" id="skillInputField"/>
						  </div>
						  <div class="modal-footer">
							<div id="mandatory_fields" class="alert alert-danger pull-left col-lg-4 col-md-6 col-sm-12 col-xs-12" role="alert" style="margin-top: 10px;display:none;">
								<strong>*</strong> Fields are mandatory
							</div>
							<button type="submit" id="submitResumeForm" class="btn btn-danger btn-md" >Apply</button>
							</form>
						  </div>
						</div>
					  </div>
					</div>
					
					
					<div class="modal fade" id="thanksModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog" style="margin-top: 100px;z-index:1050;">
						<div class="modal-content">
						  <div class="modal-body">
							<div class="alert alert-success" role="alert">Thank you for applying, we will get back to you shortly if the resume is suitable. This page will reload, once application is submitted.</div>
						  </div>
						</div>
					  </div>
					</div>
					
					</div>
	  			</div>
	  		</div>
	  		<div class="container">
	  			<!-- CUSTOMER REVIEWS -->
	  			<h2 class="with-breaker animate-me fadeInUp">
		  			Get In Touch<span>What are you waiting for ?</span>
	  			</h2>
	  		</div>
	  		<!-- CUSTOM CONTAINER -->
	  		<section class="contact-container with-separation-bottom with-separation-top">
		  		<div class="contact-boxes">
		  			<div class="contact-box contact-box-email animate-me zoomIn">
		  				<h2>Email</h2>
		  				<p>Write us a few lines about your ideas, your projects and let's advance together.</p>
		  				<a href="mailto:reachus@ellipsonic.com?Subject=Hi%20there" class="btn btn-default" target="_blank"><i class="fa fa-envelope"></i> Email Us</a>
		  			</div>
		  			<div class="contact-box contact-box-twitter animate-me zoomIn">
		  				<h2>Twitter</h2>
		  				<p>Follow us to interact, chat and share our ideas on Twitter.</p>
		  				<a href="https://twitter.com/ellipsonic" class="btn btn-default"><i class="fa fa-twitter"></i> Follow us</a>
		  			</div>
		  			<div class="contact-box contact-box-facebook animate-me zoomIn">
		  				<h2>Facebook</h2>
		  				<p>Like our page and send us message directly from our brand new Facebook page.</p>
		  				<a href="https://www.facebook.com/ellipsonic/" class="btn btn-default"><i class="fa fa-facebook"></i> Like Our Page</a>
		  			</div>
		  			<div class="contact-box contact-box-skype animate-me zoomIn">
		  				<h2>Skype</h2>
		  				<p>Call us or chat with us on Skype whenever you like, do not hesitate.</p>
		  				<a href="skype:facebook:ellipsonic?call" class="btn btn-default"><i class="fa fa-skype"></i> Call Us</a>
		  			</div>
		  		</div>
	  		</section>
	  	</div>
	  	<!-- END MAIN CONTAINER -->
	  	
	  	<!-- START FOOTER -->
	  	<footer id="footer" class="with-separation-top">
		  	<aside id="widgets" class="container">
		  		<div class="row">
		  			<!-- WIDGET -->
			  		<div class="col-md-4 widget animate-me fadeInLeft">
			  			<img src="images/logo-footer.png" id="footer-logo" alt="Logo footer" title=“logo”>
			  			<p>We are a software development company specialized in the development of web &amp; mobile based applications, desktop applications and Business Intelligence solutions.</p><a href="about.html" class="btn btn-default"><i class="fa fa-users"></i> Read more</a> 
			  		</div>
		  			<!-- WIDGET -->
			  		<div class="col-md-4 widget animate-me fadeInRight">
			  			<h4>Contact (India)</h4>
			  			<ul class="contact-informations">
							<li class="contact-address">#427/14,41st Cross, 9th Main, Jayanagar 5th Block, Bangalore, Karnataka 560041</li>
				  			<li class="contact-address">#250, 12th A Main, 6th Block, Rajajinagar, Bangalore, Karnataka 560010</li>
				  			<li class="contact-phone">+91 988 679 6816</li>
							<i class="fa fa-envelope-o"> careers@ellipsonic.com</i>
							<i class="fa fa-envelope-o"> reachus@ellipsonic.com</i>
							
			  			</ul>
			  			<ul class="widget-social">
			  				<!-- ALL ICONS AVAILABLE ->http://fortawesome.github.io/Font-Awesome/icons/#brand-->
				  			<li><a href="https://www.facebook.com/ellipsonic/" target="_blank"><i class="fa fa-facebook"></i></a></li>
				  			<li><a href="https://twitter.com/ellipsonic" target="_blank"><i class="fa fa-twitter"></i></a></li>
				  			<li><a href="skype:facebook:ellipsonic?call"><i class="fa fa-skype"></i></a></li>
			  			</ul>
			  			<a href="contact.html" class="btn btn-default"><i class="fa fa-envelope-o"></i> Contact Form</a>
			  		</div>
		  			<!-- WIDGET -->
			  		<div class="col-md-4 widget animate-me fadeInRight">
			  			<h4>Contact (Singapore)</h4>
			  			<ul class="contact-informations">
				  			<li class="contact-address">1 Yishun Industrial Street 1,<br> #06-27, A'Posh BizHub,<br> Singapore - 768160</li>
				  			<li class="contact-phone">+65 96 46 0583</li>
						<i class="fa fa-envelope-o"> careers@ellipsonic.com</i>
							<i class="fa fa-envelope-o"> reachus@ellipsonic.com</i>
			  			</ul>
			  			<ul class="widget-social">
			  				<!-- ALL ICONS AVAILABLE ->http://fortawesome.github.io/Font-Awesome/icons/#brand-->
				  			<li><a href="https://www.facebook.com/ellipsonic/" target="_blank"><i class="fa fa-facebook"></i></a></li>
				  			<li><a href="https://twitter.com/ellipsonic" target="_blank"><i class="fa fa-twitter"></i></a></li>
				  			<li><a href="skype:facebook:ellipsonic?call"><i class="fa fa-skype"></i></a></li>
				  			
			  			</ul>
			  			<a href="contact.html" class="btn btn-default"><i class="fa fa-code"></i> Contact Form</a>
			  		</div>
		  		</div>
		  	</aside>
		  	<div id="copyright" class="animate-me fadeInUp">
		  		<div class="container">
			  		<p>&#169; 2015 - 2016 All Rights Reserved. <a href="index.html">Ellipsonic PTE. LTD</a></p>
			  		<!--<ul id="footer-navigation">
				  		<li><a href="page.html">Terms of Use</a></li>
				  		<li><a href="page.html">Privacy Policy</a></li>
				  		<li><a href="contact.html">Contact Us</a></li>
			  		</ul>-->
		  		</div>
		  	</div>
	  	</footer>
	  	<!-- END FOOTER -->
	  	<input type="hidden" id="sent" value="">
	  	<!-- SCROLL TOP -->
	  	<a href="#" id="scroll-top" class="fadeInRight animate-me"><i class="fa fa-angle-double-up"></i></a>
  	</div>
	<script>
	$("document").ready(function(){
		var status = $("#sent").val();
		if(status == "true") {
			$("#thanksModal").show();
		}
	});
	  $(function () {
			$('#SkillsTab a').click(function (e) {
				e.preventDefault();
				$(this).tab('show');
			});
			
			
			/*
			$("#careerForm").on('submit', function (e) {
				//e.preventDefault();								
				if (e.isDefaultPrevented()) {
					// handle the invalid form...
					$("#mandatory_fields").show();
				} else {
					// everything looks good!
					$("#mandatory_fields").hide();
					$("#thanksModal").modal('show');
					setTimeout(function(){
					     $("#careerForm").submit();
				 	}, 3000);					
				}
			});*/
			$("#SkillsTab li").click(function() {
				$("#skillInputField").val($(this).text());
			});
			
	  });
	</script>
    <!-- SCRIPTS -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/custom.js"></script>
	<script src="js/validator.min.js"></script>
	<!-- Google analytics starts here -->
    <script>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-61134302-2', 'auto');
        ga('send', 'pageview');
    </script>
    <!-- Google analytics ends here -->
  </body>
  <!-- END BODY -->
  <style>
.tag-title-description {
     font-size: 12px;
    color: #D0D1D1;
    text-transform: none;
    font-family: "Droid serif", serif;
    font-weight: 400;
}
</style>
</html>